--------------------------------------------------
|  GTA: San Andreas Crazy IMG Editor v1.0 Final  |
--------------------------------------------------
Copyright (C) 2007 CrazyVirus
E-mail: crazyvius@inbox.ru
ICQ: 438299
Sites: 
http://crazyvirus.gtacrime.org.ru
http://crazysoft.jino-net.ru
http://crazysoft.h17.ru
--------------------------------------------------

DO NOT WRITE TO ME THE LETTER FROM HOTMAIL!!!

ACCOMMODATION ON OTHER SITES ONLY FROM THE SANCTION OF THE AUTHOR!!!


Editor of IMG archives GTA: San Andreas.


+ Works more quickly, than IMG Tool.
+ Opportunity to add some files for time.
+ Opportunity to add files with replacement and with replacement and extraction existing.
+ Ample opportunities of selection and search.
+ Opportunity to look the current size of archive and the size after rebuilding.
+ English and Russian language.